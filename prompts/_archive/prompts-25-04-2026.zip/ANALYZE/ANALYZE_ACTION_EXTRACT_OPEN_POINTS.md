## ACTION: extract_open_points

You classify items into three buckets: FACTS (skipped), `open_points`, `project_notes`.

## THE THREE BUCKETS

**FACT** → skip entirely. An item is a fact if it describes what the system does or will do with no uncertainty and no pending action. Belongs in module summaries, not in these lists.
Examples: "System saves X in CRM", "Flow forwards emails", "Module allows configuration of Y".

**`open_points`** → undecided technical/system decisions needing a choice before development starts.
Examples: data model, automation logic, integration approach, threshold values, matching algorithms, field structure.

**`project_notes`** → undecided planning/organizational items that still need to happen. Each note is categorized (see PROJECT NOTE CATEGORIES below).

## STEP 1 — Is the item OPEN?

An item is OPEN if either:
- **Explicitly unresolved** — input flags uncertainty with markers like "TBD", "to be decided", "unclear", "open question", or question marks (in any language).
- **Planning activity that must still happen** — document delivery, migration execution, testing, training, go-live timing, rollout planning.

If it describes confirmed system behavior with no pending human action → SKIP (it's a fact).

## STEP 2 — If OPEN, which bucket?

| Question | Bucket |
|---|---|
| Does this decide HOW the software works? | `open_points` |
| Can a developer act on this to write code? | `open_points` |
| Does this only decide when/who/how-fast/in-what-order? | `project_notes` |
| Does only a project manager need this to plan work? | `project_notes` |

**Hard rule:** Launch/rollout strategy is ALWAYS `project_notes`, never `open_points`. This includes go-live timing, phased rollout, pilot strategy.

## PROJECT NOTE CATEGORIES

Every `project_notes` entry MUST include a `category` field. Pick the best fit from this closed enum:

| category | Matches |
|---|---|
| `launch` | Rollout strategy, go-live timing, phased release, pilot, launch plan |
| `migration` | Data migration, legacy system cutover, export/import of existing records |
| `meeting` | Scheduled sync-up, alignment session, review meeting, retrospective |
| `follow_up` | Pending action waiting on someone, unreturned response, external dependency |
| `documentation` | Docs/guides/templates to be written, deliverables to prepare |
| `training` | User or team training plans, onboarding sessions, enablement |
| `other` | Does not clearly fit any category above |

Use `other` sparingly — prefer a specific category when possible.

## WHAT TO ACTIVELY SCAN FOR

Open items often appear without explicit markers. Watch for:

- **Alternatives stated without a choice** — "X or Y" for a numeric value, "manual or automated", "approach A, B, or C" → `open_points`
- **Integration scope ambiguity** — multiple channels/tools listed but unclear which are actually supported → `open_points`
- **Matching/linking logic** — how records connect, how payments match, entity resolution → `open_points`
- **Field capture decisions** — data points flagged as "not relevant for now" that may be needed later → `open_points`
- **Manual/automation boundaries** — "for now manual, later automated" → `open_points`
- **Proposed but not confirmed** — someone suggests something without explicit commitment → `open_points`
- **Hedging language** — "possibly", "maybe", "approximately" around a decision → `open_points`
- **Placeholder markers** — "XXX", "[value]", empty positions where concrete values are expected → `open_points`

## RULES

- Preserve exact numbers, names, and terms from the document.
- Never put the same decision in both buckets.
- Use the document's language for all `title` and `summary` fields. Never mix languages mid-output.
- `category` values are ALWAYS lowercase English enum keys, regardless of the document's language.
- When in doubt whether an item is a fact or a pending activity — if it names an action that must happen (delivery, migration, testing), it's a pending activity (`project_notes`). If it describes system behavior, it's a fact (skip).

## OUTPUT

```json
{
  "open_points": [
    { "title": "max 4 words", "summary": "1-2 short sentences" }
  ],
  "project_notes": [
    { "title": "max 4 words", "summary": "1-2 short sentences", "category": "launch" }
  ]
}
```
