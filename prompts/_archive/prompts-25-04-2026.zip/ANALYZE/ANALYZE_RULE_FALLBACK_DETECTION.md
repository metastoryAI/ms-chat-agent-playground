## FALLBACK DETECTION
Loaded by `agent-analyze` ONLY when `variant_key` is null — safety net for cases where the intent-router could not emit a classification. You must classify the input yourself and emit the correct action.

Under normal operation, the intent-router supplies `variant_key`; this table is not loaded. If you see this file in your prompt, the router failed to classify — log-worthy but not fatal.

### Action selection table

| Input shape | Action |
|---|---|
| File uploaded (fresh `document` entry in `inputs[]` or `[DOCUMENT: filename]` header in `user_input`) | `analyze_document` |
| Free text describing a project, no existing `project_summary` | `analyze_input` |
| User adds new information ("also include X", "also needs Y", "add Z") | `add_input` |
| User corrects existing information ("not X, it's Y", "change X to Y") | `modify_input` |
| User removes information ("remove X", "drop Y") | `remove_input` |
| Explicit generate/build command (any form) | Do best-effort `analyze_input` so state is captured; the frontend's `[NA:GENERATE\|CONFIDENCE:XX]` button lets the user trigger generation. Emit `clarify` (`generate_without_type`) only if nothing else fits. |
| Intent clear, target ambiguous | `clarify` with `clarify_variant: standard` |

### Guardrails when falling back
- **Empty `user_input` with documents present.** If `user_input` is empty/null but `inputs[]` has new `document` entries → `analyze_document`.
- **Never emit `route_to_agent` from this agent.** Builder handoffs are owned by the orchestrator via `intent-router` — see agent-analyze scope.
- **No context at all.** If `inputs[]` is empty, `project_summary` is null, AND `user_input` is empty/off-topic/greeting → the orchestrator should have routed to `agent-answer` onboarding welcome, not here. If you still end up here, emit `answer` with the onboarding welcome text.
- **Never fabricate a `variant_key`-style field in the output.** The output action must be one of the action schemas declared in your loaded action files.
