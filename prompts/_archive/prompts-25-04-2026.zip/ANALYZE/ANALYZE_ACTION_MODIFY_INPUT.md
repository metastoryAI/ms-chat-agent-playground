## ACTION: modify_input
Triggered when the user corrects or updates an existing item in the project context. Can target one of four lists — `target` disambiguates which.

## OUTPUT
```json
{
  "action": "modify_input",
  "target": "input | captured_topic | open_point | project_note",
  "target_title": "exact title/topic of the item being updated",
  "new_title":    "optional — only if the title itself changes",
  "new_summary":  "updated summary text (1-2 short sentence)",
  "new_category": "launch | migration | meeting | follow_up | documentation | training | other",
  "input_modification": { "target_id": "...", "topic": "...", "old_detail": "...", "new_detail": "..." },
  "captured_topics": [{ "title": "max 4 words", "summary": "1-2 short sentence", "status": "new | updated | null" }],
  "open_points":    [{ "title": "...", "summary": "..." }],
  "project_notes":  [{ "title": "...", "summary": "...", "category": "launch" }],
  "project_summary": "1-2 sentences synthesized from ALL inputs with the modification applied.",
  "project_context": { "confidence": 0, "platform_type": "app | platform | website | api_service | marketplace | ecommerce | saas_config | automation", "market_type": "b2c | b2b | internal" },
  "chat_response": { "text": "...", "hint": "..." },
  "next_actions": "[NA:GENERATE|CONFIDENCE:XX]"
}
```

## RULES
- `target` — pick the list the item lives in:
  - `input` — user-added context in `inputs[]`.
  - `captured_topic` — Covered Topics tab entry.
  - `open_point` / `project_note` — see Target Keyword Dictionary rule for disambiguation.
- `target_title` — REQUIRED. The current title of the item (case-insensitive match).
- `new_title` / `new_summary` — the updated values. Either or both may change. Use this for `target` ≠ `input`.
- `new_category` — ONLY for `target: "project_note"`. Set when the user changes the category (e.g. "move this to launch" or "this is actually a training note"). Omit for all other targets. Value must be from the closed enum (see PROJECT NOTE CATEGORIES in `extract_open_points` rule).
- `input_modification` — REQUIRED only when `target: "input"` (legacy path — describes how an additional-input entry changes).
- **Always return all four list fields** — frontend uses the returned lists as source of truth for lists other than the targeted one. For the TARGETED list: frontend applies the `new_title` / `new_summary` / `new_category` update by matching `target_title`.
- `captured_topics` — set `status: "updated"` on the changed topic, `null` elsewhere. Only when `target: "captured_topic"` or when a `modify_input` on an `input` also changes its captured topic.
- `project_notes` — every entry in this list includes `category` field (existing entries pass through unchanged).
- `project_summary` — re-synthesize only when `target: "input"`. Otherwise pass through unchanged.
- `project_context.confidence` — must match XX in `next_actions`.
- `chat_response.text` uses Template B opening line: `"**✏️ [Title] updated.**"`
