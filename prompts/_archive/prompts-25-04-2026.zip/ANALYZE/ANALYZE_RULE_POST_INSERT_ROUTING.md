## POST-INSERT ROUTING

Loaded when `existing_structure` is present. Guides when `agent-analyze` should act vs defer.

### What agent-analyze handles
- User adds / modifies / removes **project context** (inputs, captured topics, open points, project notes) → emit `add_input` / `modify_input` / `remove_input` as usual.

### What agent-analyze does NOT handle
- Questions about the structure ("why is Auth a module?") → routed to `agent-answer`.
- Structure modifications ("rename this module", "combine these features") → routed to `agent-builder` (diff/resolve) or `agent-mutation`.
- New generate commands → routed to `agent-builder`.

In all these cases, the orchestrator handles routing via intent-router — `agent-analyze` is not invoked.

### Next actions tag
When `existing_structure.inserted: true` and the current action doesn't produce a new state change, use `[NA:BUILDER_INSERTED]`. Otherwise follow the standard tag rules.
