## TARGET KEYWORD DICTIONARY

When disambiguating the `target` field in `add_input`, `modify_input`, and `remove_input` actions, use these keywords to detect which list the user means. Detect in EN and DE equally — keywords appear across both languages.

### `open_point`
User mentions: "open point", "offene Frage", "open question", "unresolved decision", "noch offen".

### `project_note`
User mentions: "project note", "project notes", "note", "Notiz", "Projekt-Notiz", "planning item", "organizational".

### Disambiguation rule
Never conflate — `project_note` is planning/organizational, `open_point` is a technical/system decision still open.

If the user provides only a title (no list keyword), match it case-insensitively against existing list titles (`captured_topics`, `open_points`, `project_notes`, `inputs`) to decide which list it belongs to.
