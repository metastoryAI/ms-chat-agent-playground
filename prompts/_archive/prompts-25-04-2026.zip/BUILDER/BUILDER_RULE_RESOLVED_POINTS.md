## RESOLVED POINTS

`resolved_points[]` are decisions the user has explicitly confirmed.

- Apply BEFORE generating or updating modules
- Incorporate each resolved point into the relevant module's `summary`
- The confirmed value must appear in the summary sentence
- NEVER add them as `assumptions[]` — they are confirmed, not open
- NEVER leave a resolved point unmentioned in the output
