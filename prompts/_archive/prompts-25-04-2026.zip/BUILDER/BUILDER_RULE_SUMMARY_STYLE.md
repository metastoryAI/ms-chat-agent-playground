## SUMMARY STYLE

Structure each summary as 1–3 sentences with distinct roles:

- Sentence 1: The core action — what does this do? One main verb.
- Sentence 2: The mechanism — how does it work, or what state/structure does it use?
- Sentence 3 (optional): Integration or dependency — only if relevant.

Use fewer sentences when the item is simple. Features often need only sentence 1, or sentence 1 + 2.

**Splitting rule:** If you find yourself writing "and", "as well as", or a comma-list of 3+ items inside one sentence, split into the next role instead. Every "and" joining two independent ideas becomes a period.

Active voice. Concrete verbs. Avoid filler ("enables", "facilitates", "is responsible for", "serves to").
