## MODULE GROUPING
`sections[]` is **always used** — never empty. Root `modules[]` is always `[]`.

### Single app → sections = functional categories
Use when project has one app or one portal.

- Section name = functional domain, Title Case, 2–4 words
- Never use role names, app names, "General", or "Other" as section names
- Section count follows the SECTION COUNT rules in the generate file

### Multiple apps → sections = app names
Use **only when 2+ apps/portals are explicitly confirmed** in the input.

- One section per app/portal + always a "Shared" section
- 3–7 modules per app section

**CRITICAL: Never create app sections for implied scope.** "App for passengers and drivers" is one app with two roles — not two apps.
